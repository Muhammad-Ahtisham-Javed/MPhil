Project Description
--------------------
The project implements the Bag-Of-Words approach to classify the 124 subjects.  “Salient Coding” has been used as encoding technique
to build high level features from low-level features. The low-level features that have been computed are HOG, MBHx and MBHy.

Dataset
--------
The dataset that has been used contains 124 subjects video files. For each subject we have 10 video files, 6 of them contains
normal walk behavior (nm1 – nm6), 2 of them contains normal walk with carrying bag behavior (bg1 – bg2) and remaining
contains normal walk with different clothing styles behavior (cl1 – cl2).

Project Structure
------------------
The project consists of 4 files altogether which should be executed in following order:
feature_extraction -> clustering -> feature_encoding -> classification


feature_extraction.ipynb
-------------------------
The goal is to randomly pick 1 million points/rows from all files. So, i am iterating through all files one by one and extracting the required
number of rows from each file and appending them to corresponding file.

clustering.ipynb
-----------------
In this code i am calling k-means clustering on 1 million points of hog, mbhx and mbhy using 256 clusters.

feature_encoding.ipynb
-----------------------
The salient coding technique has been implemented in this file using k=5. There will be three arrays (hog, mbhx and mbhy) each of size 1240x256
to represent histograms of all files. Each row in an array represents histogram for single complete file. The "perform_encoding" method does the
encoding of single feature by applying the saliency degree formula. We need labels of files as well for classification purpose therefore i am
concatenating the labels with computed euclidean distances as well. The mapping of string labels to integer labels has been mentioned in file.

classification.ipynb
---------------------
Once the encoding step has been completed, we move towards concatenation step. The three corresponding encoded features are concatenated
horizontally. And after that classification is performed in 3 experiments. The training data for classification is same for all experiments
i.e nm1 to nm4, but testing data for experiments are nm5 - nm6, bg1 - bg2 and cl1 - cl2 respectively.