// part # 2 ===== pipes



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>

//macros

#define MAX_LEN 512
#define MAXARGS 10
#define ARGLEN 30

int executec(char* arglist[]);
char** tokenizec(char* cmdline);
char* read_cmdc(char*, FILE*);
int nPipes(char** al, int an);

int argnum = 0; //slots used
int main(){
	//main function starts
   char *cmdline;
   char** arglist;
   char prompt[1024];
   getcwd(prompt,1024);
   //getting path of present working direcotry  
   while((cmdline = read_cmdc(prompt,stdin)) != NULL){
      if((arglist = tokenizec(cmdline)) != NULL){
            executec(arglist);
       // freeing the argument list
         for(int j=0; j < MAXARGS+1; j++)
	         free(arglist[j]);
         free(arglist);
         free(cmdline);
      }
      //ending if structure
  } 
  //end of while loop
   printf("\n");
   return 0;
}
int nPipes(char** al, int an)
{
	int n=0;
	for(int i=0; i<an; i++)
   {
		if(al[i][0]=='|')
      {
			n++;		
		}
	}
	return n;
}
int executec(char* arglist[]){
	int np=nPipes(arglist, argnum);
   int status;
	int cpid = fork();
	signal(SIGINT, SIG_IGN);//ignore ctrl+c for child process

   if(np == 0)
   {
      //without using pipes
      if(cpid==-1)
      {//condition 1
         perror("fork failed");
         exit(1);
      }
      if(cpid==0)
      {//2nd condition
         for(int i=0;i<argnum;i++) //traverse
         {
            if(arglist[i][0]=='<') // find '<'
            {
               int fd0 = open(arglist[i+1], O_RDONLY);
               dup2(fd0, STDIN_FILENO);
               close(fd0);
               for(int j=i;j<argnum-2;j++)
               { //skip filename from list and that is already opend 
                  arglist[j]=arglist[j+2];
               }
               arglist[argnum-2]=NULL;
               arglist[argnum-1]=NULL;
               argnum-=2;
               i--;
            }
            if(arglist[i][0]=='>') //find '>'
            {
               int fd1 = open(arglist[i+1] , O_WRONLY|O_CREAT, 0777) ;
               dup2(fd1, STDOUT_FILENO);
               close(fd1);
               for(int j=i;j<argnum-2;j++)
               {
                  arglist[j]=arglist[j+2];
               }
               arglist[argnum-2]=NULL;
               arglist[argnum-1]=NULL;
               argnum-=2;
               i--;
            }
         }
         execvp(arglist[0], arglist);
         perror("Command not found...");
         exit(1);
      }
      if(cpid  != 0 && cpid != -1)
      {//condition 3
         waitpid(cpid, &status, 0);
         printf("child exited with status %d \n", status >> 8);
      }
   return 0;
   }


   if(np!=0) //withpipes
   {
      char** arglist1;
      char** arglist2;

      int fd[2];
      int rv = pipe(fd);
	   if (rv == -1)
      {
	      printf("pipe faied");
	      exit(1);
	   }
      pid_t cpid = fork();
	   int i = 0;
      int j = 0;
	   if (cpid != 0)
      { 
         dup2(fd[1], 1); 
         //redirecting stdout to write end of pipe
         close(fd[0]); 
         //close it
	      for(i=0;i<argnum; i++)
         {
		      if(arglist[i][0]!='|')
            {
			      arglist1[i]=arglist[i];
		      }

		      else if(arglist[i][0]=='|')
            {
			      arglist1[i]=NULL;
			      i++;
			      break;
			   }
	      }
         execvp(arglist1[0], arglist1);
      }
   
      else
      {  
         //child process code
         dup2(fd[0], 0); 
         //redirect stdin to read end of pipe
         close(fd[1]);    //closing it
	      for(; i < argnum; i++)
         {
		      if(arglist[i][0]!='|')
            {
			      arglist2[j++]=arglist[i]; //i have changed i with j
		      }
	      }
         execvp(arglist2[0], arglist2);
         // command after pipe
      } 
      return 0;
   }
}


char** tokenizec(char* cmdline){
   //allocate memory using malloc 
   char** arglist = (char**)malloc(sizeof(char*)* (MAXARGS+1));
   for(int j=0; j < MAXARGS+1; j++){
      arglist[j] = (char*)malloc(sizeof(char)* ARGLEN);
      bzero(arglist[j],ARGLEN);
   }
   if(cmdline[0] == '\0')
      //if user press enter without any command
      return NULL;
   argnum = 0;
   char*cp = cmdline; 
   //pos in string
   char*start;
   int len;
   while(*cp != '\0'){
      while(*cp == ' ' || *cp == '\t') 
         //skipping leading spaces
         cp++;
      start = cp; 
      len = 1;
      //finding the end of the word
      while(*++cp != '\0' && !(*cp ==' ' || *cp == '\t'))
         len++;
      strncpy(arglist[argnum], start, len);
      arglist[argnum][len] = '\0';
      argnum++;
   }
	
   arglist[argnum] = NULL;
   return arglist;
}      


char* read_cmdc(char* prompt, FILE* fp){
   printf("\033[1;32mshellv2.2@%s\033[0m:$ ", prompt);
   int c; 
   //inputting character
   int pos = 0; //position of character in cmdline
   char* cmdline = (char*) malloc(sizeof(char)*MAX_LEN);
   while((c = getc(fp)) != EOF){
      if(c == '\n')
	      break;
      cmdline[pos++] = c;
   }
   if(c == EOF && pos == 0) 
      // exiting the shell
      return NULL;
   cmdline[pos] = '\0';
   return cmdline;
} 