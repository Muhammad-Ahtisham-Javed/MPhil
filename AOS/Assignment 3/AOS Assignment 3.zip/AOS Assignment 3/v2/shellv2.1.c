//VERSION # 2.1

// part # 1 for redirecting stdin and stdout

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>

//macros
#define MAX_LEN 512
#define MAXARGS 10
#define ARGLEN 30


//functions use
int executeb(char* arglist[]);
char** tokenizeb(char* cmdline);
char* read_cmdb(char*, FILE*);

int argnum = 0; //slots used
int main(){
	//entering function main
   char *cmdline;
   char** arglist;
   char prompt[1024];
   getcwd(prompt,1024);  //get path of present working directory 
   while((cmdline = read_cmdb(prompt,stdin)) != NULL){
      if((arglist = tokenizeb(cmdline)) != NULL){
         executeb(arglist);
         // freeing the argument list
         for(int j=0; j < MAXARGS+1; j++)
	         free(arglist[j]);
         free(arglist);
         free(cmdline);
      }
    //ending if statement
  }
  //end of while loop
   printf("\n\n\n\n\n");
   return 0;
}
int executeb(char* arglist[]){
		
   int status;
   int cpid = fork();
	signal(SIGINT, SIG_IGN);//ignore ctrl+c for child process
   switch(cpid){
      case -1:
         perror("fork failed");
	      exit(1);
      case 0:
	      for(int i=0;i<argnum;i++) //traverse
         {
            if(arglist[i][0]=='<') // find '<'
            {
               int fd0 = open(arglist[i+1], O_RDONLY);
               dup2(fd0, STDIN_FILENO);
               close(fd0);
               for(int j=i;j<argnum-2;j++)
               { //skip filename from list and that is already opend 
                  arglist[j]=arglist[j+2];
               }
               arglist[argnum-2]=NULL;
               arglist[argnum-1]=NULL;
               argnum-=2;
               i--;
            }
            if(arglist[i][0]=='>') //find '>'
            {
               int fd1 = open(arglist[i+1] , O_WRONLY|O_CREAT, 0777) ;
               dup2(fd1, STDOUT_FILENO);
               close(fd1);
               for(int j=i;j<argnum-2;j++)
               {
                  arglist[j]=arglist[j+2];
               }
               arglist[argnum-2]=NULL;
               arglist[argnum-1]=NULL;
               argnum-=2;
               i--;
            }
         }
	      execvp(arglist[0], arglist);
 	      perror("Command not found...");
	      exit(1);
      default:
	      waitpid(cpid, &status, 0);
         printf("child exited with status %d \n", status >> 8);
         return 0;
   }
}



char** tokenizeb(char* cmdline){
	//printf(" tokenizeb ");
   //allocating memory using malloc family of calls
   char** arglist = (char**)malloc(sizeof(char*)* (MAXARGS+1));
   for(int j=0; j < MAXARGS+1; j++){
	   arglist[j] = (char*)malloc(sizeof(char)* ARGLEN);
      bzero(arglist[j],ARGLEN);
    }
   if(cmdline[0] == '\0')
   //command without space
      return NULL;
   argnum = 0;
   char*cp = cmdline; 
   char*start;
   int len;
   while(*cp != '\0'){
      while(*cp == ' ' || *cp == '\t') 
     // for skipping space
          cp++;
      start = cp; //start of the word
      len = 1;
      //finding the end of the word
      while(*++cp != '\0' && !(*cp ==' ' || *cp == '\t'))
         len++;
      strncpy(arglist[argnum], start, len);
      arglist[argnum][len] = '\0';
      argnum++;
   }
	
   arglist[argnum] = NULL;
   return arglist;
}      



char* read_cmdb(char* prompt, FILE* fp){
	//read-cmd
   printf("\033[1;32mshellv2.1@%s\033[0m:$ ", prompt);
   int c; 
   //for inputing character
   int pos = 0;
   //position of character in cmdline
   char* cmdline = (char*) malloc(sizeof(char)*MAX_LEN);
   while((c = getc(fp)) != EOF){
      if(c == '\n')
	      break;
      cmdline[pos++] = c;
   }
   // in case of using capital ctrl+d to exit the shell
   if(c == EOF && pos == 0) 
      return NULL;
   cmdline[pos] = '\0';
   return cmdline;
} 