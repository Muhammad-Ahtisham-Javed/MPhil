// VERSION # 4 for maintaining history



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

// macros
#define MAX_LEN 512
#define MAXARGS 10
#define ARGLEN 30

int executea(char* arglist[]);
char** tokenizee(char* cmdline);
char* read_cmde(char*, FILE*);


void saveInFile(char* cmdline)
{
    FILE* fp=fopen("historyfile.txt","a+");
    char arr[1024];
    char last[1024];
    char n[10]="\0";
    fseek(fp,0,SEEK_SET);
    int flag=0;
    while(!feof(fp))
    {
        flag=1;
        fgets(arr,1024,fp);
        strncpy(last,arr,1024);
    }
    int no=0;
    if(flag==1)
    {
        int i=0;
        while(last[i]!=' ')
        {
            n[i]=last[i];
            i++;
        }
        no=atoi(n);
    }
    no+=1;

    fprintf(fp, "%d    ", no);
    fprintf(fp,"%s\n",cmdline );
    fclose(fp);
}

int getCommandFromFile(char* cmdline)
{
    FILE* fp=fopen("historyfile.txt","a+");
    char t='\0';
    int totalno=0;
    char n[10]="\0";
    if(cmdline[1]!='-')
    {
        int i=1,k=0;
        while(cmdline[i]!='\0')
        {
            n[k]=cmdline[i];
            i++;k++;
        }

        t='+';
    }
    else 
    {
        int i=2,k=0;
        while(cmdline[i]!='\0')
        {
            n[k]=cmdline[i];
            i++;k++;
        } 
        t='-';
        fseek(fp,0,SEEK_SET);
        char last[1024],arr[1024],no[10];
        while(!feof(fp))
        {
            fgets(arr,1024,fp);
            strncpy(last,arr,1024);
        }
        i=0;
        while(last[i]!=' ')
        {
            no[i]=arr[i];
            i++;
        }   
        totalno=atoi(no);
        totalno++;
    }
    int no=atoi(n);
    if(t=='-')
        no=totalno-no;
    char arr[1024];
    fseek(fp,0,SEEK_SET);
    while(!feof(fp))
    {
        fgets(arr,1024,fp);
        char n2[10]="\0";
        int i=0;
        while(arr[i]!=' ')
        {
            n2[i]=arr[i];
            i++;
        }   
        int no2=atoi(n2);
        if(no2==no)
        {
            int k=0;
            while(k<100)
            {
                cmdline[k]='\0';
                k++;
            }
            while(arr[i]==' ')
                i++;
            k=0;
            while(arr[i]!='\0')
            {
                cmdline[k]=arr[i];
                k++;i++;
            }
            cmdline[--k]='\0';
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return -1;
}

int main(){

    char *cmdline;
    char** arglist;
    char prompt[1024];
    getcwd(prompt,1024); //getting path of present working directory  
    while((cmdline = read_cmde(prompt,stdin)) != NULL){
	    if(cmdline[0]=='!'){
            int rv= getCommandFromFile(cmdline);
            if(rv==-1){
                printf("No commands in history.\n");
                continue;
            }
        }
        if((arglist = tokenizee(cmdline)) != NULL){
            executea(arglist); // freeing argument list
            for(int j=0; j < MAXARGS+1; j++)
                free(arglist[j]);
            free(arglist);
            free(cmdline);
        }
        //closing if structure
    }
    //end of while loop
    printf("\n");
    return 0;
}

int executea(char* arglist[]){
    // executea function
    int status;
    int cpid = fork();
    signal(SIGINT, SIG_IGN);//ignore ctrl+c for child process
	
    switch(cpid){
        case -1:
            perror("fork failed");
	        exit(1);
        case 0:		
            execvp(arglist[0], arglist);
            perror("Command not found...");
		
            exit(1);
        default:
            waitpid(cpid, &status, 0);
            printf("child exited with status %d \n", status >> 8);
            return 0;
    }
}

char** tokenizee(char* cmdline){
    // tokenizee
    //allocainge memory
    char** arglist = (char**)malloc(sizeof(char*)* (MAXARGS+1));
    for(int j=0; j < MAXARGS+1; j++){
	    arglist[j] = (char*)malloc(sizeof(char)* ARGLEN);
        bzero(arglist[j],ARGLEN);
    }
    if(cmdline[0] == '\0')//if user press enter without any command
        return NULL;
    int argnum = 0; //slots used
    char*cp = cmdline; // pos in string
    char*start;
    int len;
    while(*cp != '\0'){
        while(*cp == ' ' || *cp == '\t') //skipping leading spaces
            cp++;
        start = cp; //start of the word
        len = 1; //finding the end of the word
        while(*++cp != '\0' && !(*cp ==' ' || *cp == '\t'))
            len++;
        strncpy(arglist[argnum], start, len);
        arglist[argnum][len] = '\0';
        argnum++;
    }
    arglist[argnum] = NULL;
    return arglist;
}      

char* read_cmde(char* prompt, FILE* fp){
    //read-cmd 
    printf("\033[1;32mshellv4@%s\033[0m:$ ", prompt);
    int c; 
    //inputting character
    int pos = 0; //position of character in cmdline
    char* cmdline = (char*) malloc(sizeof(char)*MAX_LEN);
    while((c = getc(fp)) != EOF){
        if(c == '\n')
	        break;
        cmdline[pos++] = c;
    }
    //in case of capital ctrl+d to exit the shell
    if(c == EOF && pos == 0) 
        return NULL;
    cmdline[pos] = '\0';
    if(cmdline[0]!='!' && cmdline!="\0" && cmdline!="" && cmdline!="\n")
        saveInFile(cmdline);
    return cmdline;
} 
