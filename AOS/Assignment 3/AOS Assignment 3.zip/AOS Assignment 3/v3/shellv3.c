//VERSION # 3 HANDLING SEMICOLON

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>


//macros
#define MAX_LEN 512
#define MAXARGS 10
#define ARGLEN 30

int executed(char* arglist[]);
char** tokenized(char* cmdline);
char** tokenizedColon(char* cmdline);
char* read_cmdd(char*, FILE*);
int argnuma = 0;

int main(){
	//main function starts
   char *cmdline;
   char** arglist;
   char** arglista;
   char prompt[1024];
   getcwd(prompt,1024); //get path of present working directory 
   while((cmdline = read_cmdd(prompt,stdin)) != NULL){
      if((arglista = tokenizedColon(cmdline)) != NULL){
	      int i=0;
         while(i<argnuma){
		      if((arglist = tokenized(arglista[i])) != NULL){
            executed(arglist);
            // freeing argument list
            for(int j=0; j < MAXARGS+1; j++)
	            free(arglist[j]);
            free(arglist);
            }
	         i++;
	      }
	      for(int j=0; j < MAXARGS+1; j++)
            free(arglista[j]);
         free(arglista);
      }
      free(cmdline);
   }

   //ending while loop
   printf("\n");
   return 0;
}
   

int executed(char* arglist[]){

   int status;
   int cpid = fork();
	signal(SIGINT, SIG_IGN);//ignore ctrl+c for child process
	
   switch(cpid){
      case -1:
         perror("fork failed");
	      exit(1);
      case 0:
	      execvp(arglist[0], arglist);
 	      perror("Command not found...");
		
	      exit(1);
      default:
	      waitpid(cpid, &status, 0);
         printf("child exited with status %d \n", status >> 8);
         return 0;
   }
}

char** tokenized(char* cmdline){
   //allocating memory using malloc family of calls
   char** arglist = (char**)malloc(sizeof(char*)* (MAXARGS+1));
   for(int j=0; j < MAXARGS+1; j++){
	   arglist[j] = (char*)malloc(sizeof(char)* ARGLEN);
      bzero(arglist[j],ARGLEN);
   }
   if(cmdline[0] == '\0')//if user press enter without any command
      return NULL;
   int argnum = 0; //slots used
   char*cp = cmdline; // pos in string
   char*start;
   int len;
   while(*cp != '\0'){
      while(*cp == ' ' || *cp == '\t') //skip spaces
         cp++;
      start = cp; //start of the word
      len = 1;
      //find the end of the word
      while(*++cp != '\0' && !(*cp ==' ' || *cp == '\t'))
         len++;
      strncpy(arglist[argnum], start, len);
      arglist[argnum][len] = '\0';
      argnum++;
   }
   arglist[argnum] = NULL;
   return arglist;
}      

char** tokenizedColon(char* cmdline){
	
// allocating memory using malloc family of calls
   char** arglist = (char**)malloc(sizeof(char*)* (MAXARGS+1));
   for(int j=0; j < MAXARGS+1; j++){
	   arglist[j] = (char*)malloc(sizeof(char)* ARGLEN);
      bzero(arglist[j],ARGLEN);
   }
   if(cmdline[0] == '\0')
   //pressing enter without command
      return NULL;
   argnuma = 0; //slots used
   char*cp = cmdline; // pos in string
   char*start;
   int len;
   while(*cp != '\0'){
      while(*cp == ' ' || *cp == '\t' ||  *cp==';') //skip spaces and colon
         cp++;
      start = cp; //start of the word
      len = 1;
      //finding the end of the word
      while(*++cp != '\0' && !(*cp ==' ' || *cp == '\t') && *cp != ';')
         len++;
      strncpy(arglist[argnuma], start, len);
      arglist[argnuma][len] = '\0';
      argnuma++;
   }
   arglist[argnuma] = NULL;
   return arglist;
}      

char* read_cmdd(char* prompt, FILE* fp){
	//printf(" read-cmd ");
   printf("\033[1;32mshellv3@%s\033[0m:$ ", prompt);
   int c; //input character
   int pos = 0; //position of character in cmdline
   char* cmdline = (char*) malloc(sizeof(char)*MAX_LEN);
   while((c = getc(fp)) != EOF){
      if(c == '\n')
	      break;
      cmdline[pos++] = c;
   }
   //pressing capital ctrl+d to exit the shell
   if(c == EOF && pos == 0) 
      return NULL;
   cmdline[pos] = '\0';
   return cmdline;
} 
